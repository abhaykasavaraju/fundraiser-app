export default [
    {
        id:1,
        heading: "Library Rebuilding",
        description: " Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse ut congue lorem, vitae mattis augue. Curabitur luctus congue mi. Praesent et nisi tristique libero consequat finibus vel vitae ante. Proin posuere suscipit tellus, ultrices facilisis nunc pellentesque non. Mauris ex velit, rutrum sed blandit ut, lacinia vitae magna. Donec bibendum enim sit amet ipsum rhoncus volutpat. Aenean rutrum ipsum quis felis cursus, ac porttitor ex tempus. Nam vel ante rhoncus felis scelerisque convallis vel et sapien. Sed quis arcu blandit, faucibus libero et, aliquet velit. Nulla velit massa, dignissim sed ligula ac, posuere consectetur purus. Vivamus ac convallis diam. Donec viverra, lorem at tincidunt tempor, tortor tellus auctor dui, nec faucibus leo orci at mauris. Suspendisse vestibulum varius massa sit amet faucibus. Ut sit amet sagittis tortor, at tempus justo. Integer nec quam euismod, pellentesque mi at, molestie sapien. In sit amet maximus ante.",
        collectedAmount : 2000,
        goalAmount : 50000,
        postedBy: "Abhay Kasavaraju",
        UPI : "abhay@upi.com",
        phoneNumber : 9100216545,
        email: "abhaykasavaraju@gmail.com",
        isSelected : false,
        showDetails: false,
        src : "/library.jpg"
    },

    {
        id:2,
        heading: "Covid Relief Fund",
        description: " To bear medical expenses of students affected by Covid-19.Suspendisse ut congue lorem, vitae mattis augue. Curabitur luctus congue mi. Praesent et nisi tristique libero consequat finibus vel vitae ante. Proin posuere suscipit tellus, ultrices facilisis nunc pellentesque non. Mauris ex velit, rutrum sed blandit ut, lacinia vitae magna. Donec bibendum enim sit amet ipsum rhoncus volutpat. ",
        collectedAmount : 60000,
        goalAmount : 100000,
        postedBy: "Suraj Pingali",
        UPI : "suraj@upi.com",
        phoneNumber : 9999999999,
        email : "surajpingali2000@gmail.com",
        isSelected : false,
        showDetails: false,
        src : "/covid-cells.jpg"

        


    }
];