import React from 'react'
import './Header.css'

function Header() {
    return (
        <div >
            <h1 className="page-header">Fundraising Page</h1>
        </div>
    )
}

export default Header
