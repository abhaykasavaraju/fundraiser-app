import React from 'react';
import '../App.css';  
import './HeroSection.css';

function HeroSection() {
  return (
    <div className='hero-container'>
      <video src='/videos/video-1.mp4' autoPlay loop muted />
      <h1>Alumni Events</h1>
      <p>Spells of reminiscence</p>
      <div className='hero-btns'>
        {/* <Button
          className='btns'
          buttonStyle='btn--outline'
          buttonSize='btn--large'
        >
          GET STARTED
        </Button>
        <Button
          className='btns'
          buttonStyle='btn--test'
          buttonSize='btn--large'
          onClick={console.log('hey')}
        >
          JOIN THE ALUMINI NETWORK <i className='far fa-play-circle' />
        </Button> */}

        <button className="btn btn-primary">Get Started</button>
        <button className="btn btn-primary">Join Network</button>

      </div>
    </div>
  );
}

export default HeroSection;